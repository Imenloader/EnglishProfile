export interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: string;
  category: 'grammar' | 'vocabulary' | 'advanced';
  part: 1 | 2;
}

export const placementQuestions: Question[] = [
  // PART 1: Grammar (40 Questions)
  { id: 1, part: 1, category: 'grammar', question: "Are you a student? No, I ……….", options: ["am not", "not am", "don't"], correctAnswer: "am not" },
  { id: 2, part: 1, category: 'grammar', question: "Where is Matthew? He's …….", options: ["in the supermarket", "about the supermarket", "on the supermarket"], correctAnswer: "in the supermarket" },
  { id: 3, part: 1, category: 'grammar', question: "………………….. a beautiful day.", options: ["when", "where", "what"], correctAnswer: "what" },
  { id: 4, part: 1, category: 'grammar', question: "…………….. a great movie at the Plaza.", options: ["There are", "There is", "There"], correctAnswer: "There is" },
  { id: 5, part: 1, category: 'grammar', question: "My parents’ house has four ……………", options: ["rooms", "room", "the rooms"], correctAnswer: "rooms" },
  { id: 6, part: 1, category: 'grammar', question: "I ……….to England with my family in 2010.", options: ["have been", "have gone", "went"], correctAnswer: "went" },
  { id: 7, part: 1, category: 'grammar', question: "I………….. to France three times.", options: ["gone", "traveled", "have been"], correctAnswer: "have been" },
  { id: 8, part: 1, category: 'grammar', question: "I have ………….. because I lifted something heavy.", options: ["a backache", "a headache", "toothache"], correctAnswer: "a backache" },
  { id: 9, part: 1, category: 'grammar', question: "I ………. when I was 28.", options: ["got marry", "got married", "married"], correctAnswer: "got married" },
  { id: 10, part: 1, category: 'grammar', question: "Did you ……. to the club last night?", options: ["have gone", "went", "go"], correctAnswer: "go" },
  { id: 11, part: 1, category: 'grammar', question: "I …………. since 9:00 am.", options: ["have been waiting", "start", "went"], correctAnswer: "have been waiting" },
  { id: 12, part: 1, category: 'grammar', question: "I’m going …… friends at the café at 7:00 pm tomorrow.", options: ["meeting", "to meet", "meet"], correctAnswer: "to meet" },
  { id: 13, part: 1, category: 'grammar', question: "I ………smoke, but now I don't.", options: ["did", "am used to", "used to"], correctAnswer: "used to" },
  { id: 14, part: 1, category: 'grammar', question: "I am used to playing football, that means:", options: ["I don't play football now.", "I started to play football and I'm still playing.", "I am playing football sometimes."], correctAnswer: "I started to play football and I'm still playing." },
  { id: 15, part: 1, category: 'grammar', question: "……………it cloudy yesterday?", options: ["Was", "Were", "Is"], correctAnswer: "Was" },
  { id: 16, part: 1, category: 'grammar', question: "I…………….my doctor at 8.00 p.m. at his clinic next week.", options: ["am seeing", "am going to", "go to"], correctAnswer: "am seeing" },
  { id: 17, part: 1, category: 'grammar', question: "The match ……….at 5.00 Pm.", options: ["will start", "start", "starting"], correctAnswer: "will start" },
  { id: 18, part: 1, category: 'grammar', question: "I think I ………. spend my summer vacation in London.", options: ["will", "am going to", "will go to"], correctAnswer: "will" },
  { id: 19, part: 1, category: 'grammar', question: "The thief was able to steal my bag because I ………………. to lock it.", options: ["had forgotten", "forgotten", "forget"], correctAnswer: "had forgotten" },
  { id: 20, part: 1, category: 'grammar', question: "It………. raining since morning.", options: ["is", "has been", "has"], correctAnswer: "has been" },
  { id: 21, part: 1, category: 'grammar', question: "I ……. this restaurant twenty years ago.", options: ["owned", "have been owning", "have owned"], correctAnswer: "owned" },
  { id: 22, part: 1, category: 'grammar', question: "They have ………………geography six years ago.", options: ["studied", "been studying", "already studied"], correctAnswer: "already studied" },
  { id: 23, part: 1, category: 'grammar', question: "We need a plumber in order to ………. the bathtub.", options: ["fixed", "fixing", "fix"], correctAnswer: "fix" },
  { id: 24, part: 1, category: 'grammar', question: "I have my hair cut ……… a month.", options: ["two", "two time", "twice"], correctAnswer: "twice" },
  { id: 25, part: 1, category: 'grammar', question: "…………. time do you spend at the gym.", options: ["How much", "What", "How many"], correctAnswer: "How much" },
  { id: 26, part: 1, category: 'grammar', question: "The right order for these words from the least to the much amount is:", options: ["a few-quiet a few- just the right amount-much- too much", "a few-few-quite a few - - just the right amount-much- too much", "quite a few- a few-few-- just the right amount-much- too much"], correctAnswer: "a few-few-quite a few - - just the right amount-much- too much" },
  { id: 27, part: 1, category: 'grammar', question: "In Egypt, men ………enter into the army.", options: ["must", "have to", "should"], correctAnswer: "have to" },
  { id: 28, part: 1, category: 'grammar', question: "'I …. study for my exams'. The student said to herself.", options: ["will", "have to", "must"], correctAnswer: "must" },
  { id: 29, part: 1, category: 'grammar', question: "………….is her hair?", options: ["What colour", "what is the colour", "Which colour"], correctAnswer: "What colour" },
  { id: 30, part: 1, category: 'grammar', question: "The woman ……next door is a doctor.", options: ["who lives", "who, lives,", "lives"], correctAnswer: "who lives" },
  { id: 31, part: 1, category: 'grammar', question: "My brother Khaled …….in London, is an engineer.", options: ["lives", "who lives", ",who lives"], correctAnswer: ",who lives" },
  { id: 32, part: 1, category: 'grammar', question: "I am a short person, I wish I ……. taller.", options: ["am", "were", "be"], correctAnswer: "were" },
  { id: 33, part: 1, category: 'grammar', question: "You ………call Linda, she would be able to help you.", options: ["could", "should", "can"], correctAnswer: "should" },
  { id: 34, part: 1, category: 'grammar', question: "I wish I ………….to my parents’ advice.", options: ["listened", "have listened", "could listened"], correctAnswer: "listened" },
  { id: 35, part: 1, category: 'grammar', question: "It is very exciting, ………., it is so expensive.", options: ["whereas", "meanwhile", "however"], correctAnswer: "however" },
  { id: 36, part: 1, category: 'grammar', question: "What is the ………. planet to earth?", options: ["farest", "furthest", "far"], correctAnswer: "furthest" },
  { id: 37, part: 1, category: 'grammar', question: "I hate ………on weekends.", options: ["work", "to work", "working"], correctAnswer: "working" },
  { id: 38, part: 1, category: 'grammar', question: "Taxes …………………this year ,however, they ………………..last year.", options: ["are going to be raised- were raised", "are rising- raised", "will raise- have been raised"], correctAnswer: "are going to be raised- were raised" },
  { id: 39, part: 1, category: 'grammar', question: "I was thinking a lot and decided that I …………………….travel to London on the next summer vacation.", options: ["will", "am going to", "do"], correctAnswer: "am going to" },
  { id: 40, part: 1, category: 'grammar', question: "The bill was …………to ring, while I was studying for ………….my ex-girlfriend.", options: ["able – about", "about – of", "going – in"], correctAnswer: "about – of" },

  // PART 2: Vocabulary & Advanced (20 Questions)
  { id: 41, part: 2, category: 'vocabulary', question: "What is the opposite of 'hot'?", options: ["warm", "cold", "sunny", "wet"], correctAnswer: "cold" },
  { id: 42, part: 2, category: 'vocabulary', question: "Which word describes how you feel when you need to sleep?", options: ["hungry", "thirsty", "tired", "angry"], correctAnswer: "tired" },
  { id: 43, part: 2, category: 'vocabulary', question: "My brother is ……… years old. He was born in 2015.", options: ["eight", "nine", "ten", "eleven"], correctAnswer: "nine" },
  { id: 44, part: 2, category: 'vocabulary', question: "We eat lunch in the ……….", options: ["morning", "night", "afternoon", "evening"], correctAnswer: "afternoon" },
  { id: 45, part: 2, category: 'vocabulary', question: "She goes to the ………. to buy medicine.", options: ["bakery", "pharmacy", "library", "butcher"], correctAnswer: "pharmacy" },
  { id: 46, part: 2, category: 'vocabulary', question: "Which word means 'to begin'?", options: ["finish", "stop", "start", "wait"], correctAnswer: "start" },
  { id: 47, part: 2, category: 'vocabulary', question: "The weather today is ………. . You need an umbrella.", options: ["windy", "cloudy", "rainy", "foggy"], correctAnswer: "rainy" },
  { id: 48, part: 2, category: 'vocabulary', question: "He is a very ………. person. He always helps others.", options: ["lazy", "selfish", "kind", "rude"], correctAnswer: "kind" },
  { id: 49, part: 2, category: 'advanced', question: "The company decided to ………. the meeting until next week.", options: ["cancel", "postpone", "attend", "arrange"], correctAnswer: "postpone" },
  { id: 50, part: 2, category: 'advanced', question: "She gave a very ………. speech. Everyone was impressed.", options: ["fluent", "average", "boring", "convincing"], correctAnswer: "convincing" },
  { id: 51, part: 2, category: 'advanced', question: "Which word is closest in meaning to 'angry'?", options: ["upset", "furious", "nervous", "worried"], correctAnswer: "furious" },
  { id: 52, part: 2, category: 'advanced', question: "He couldn't afford the car because it was beyond his ……….", options: ["reach", "limit", "budget", "plan"], correctAnswer: "budget" },
  { id: 53, part: 2, category: 'advanced', question: "The new policy will ………. all employees, regardless of their position.", options: ["involve", "affect", "include", "apply"], correctAnswer: "affect" },
  { id: 54, part: 2, category: 'advanced', question: "The project was ………. due to a lack of funding.", options: ["abandoned", "approached", "admitted", "attached"], correctAnswer: "abandoned" },
  { id: 55, part: 2, category: 'advanced', question: "The report was ………., with every detail carefully checked.", options: ["thorough", "vague", "brief", "rough"], correctAnswer: "thorough" },
  { id: 56, part: 2, category: 'advanced', question: "Despite working hard, she failed to ………. her targets this quarter.", options: ["reach", "meet", "do", "make"], correctAnswer: "meet" },
  { id: 57, part: 2, category: 'advanced', question: "The politician's statement was deliberately ………., leaving room for different interpretations.", options: ["precise", "ambiguous", "straightforward", "blunt"], correctAnswer: "ambiguous" },
  { id: 58, part: 2, category: 'advanced', question: "The new regulation is intended to ………. unfair business practices.", options: ["curb", "expand", "promote", "overlook"], correctAnswer: "curb" },
  { id: 59, part: 2, category: 'advanced', question: "Her argument was so ………. that even her opponents had to agree.", options: ["vague", "redundant", "compelling", "obscure"], correctAnswer: "compelling" },
  { id: 60, part: 2, category: 'advanced', question: "The CEO's decision to restructure the company was met with ………. from the board.", options: ["applause", "skepticism", "enthusiasm", "indifference"], correctAnswer: "skepticism" },
];
